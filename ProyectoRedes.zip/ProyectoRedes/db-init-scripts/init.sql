CREATE DATABASE IF NOT EXISTS sistema;
USE sistema;
create table patentes(patente VARCHAR(45));
